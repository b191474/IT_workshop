<? php
$ server= "localhost";
$username= "
$password= "_", " ",
$db="student";
$conn=mysqli_connect($server,$username,$password,$db);
if(i&$conn)
{
echo "unsuccessful connection";
}
else{
echo "connect succesfully";
}
?>
